package com.example.clinicaOdontologica.controller;


import com.example.clinicaOdontologica.models.Paciente;
import com.example.clinicaOdontologica.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/pacientes")
@CrossOrigin("*")
public class PacienteController {
    @Autowired
    private PacienteService pacienteService;

    @PostMapping()
    public ResponseEntity<Paciente> registrarOdontologo(@RequestBody Paciente paciente){
        Paciente nuevoPaciente = pacienteService.guardar(paciente);
        if(nuevoPaciente != null){
            return ResponseEntity.ok(nuevoPaciente);
        }else{
            return ResponseEntity.internalServerError().body(null);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Paciente> buscar(@PathVariable Integer id){
        Paciente pacienteBuscado = pacienteService.buscar(id);
        if(pacienteBuscado != null){
            return ResponseEntity.ok(pacienteBuscado);
        }else{
            return ResponseEntity.badRequest().body(null);
        }
    }

    @PutMapping()
    public ResponseEntity<Paciente> actualizar(@RequestBody Paciente paciente){
        ResponseEntity<Paciente> responde=null;
        Paciente pacientePorActualizar = pacienteService.buscar(paciente.getId());
        if(pacientePorActualizar != null){
            return ResponseEntity.ok(pacienteService.actualizar(paciente));
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @DeleteMapping(value= "/{id}")
    public ResponseEntity eliminar(@PathVariable Integer id) {
        if (pacienteService.eliminar(id)) {
            return ResponseEntity.ok("Paciente con id " + id + " fue eliminado");
        } else {
            return ResponseEntity.badRequest().body("Paciente con id " + id + " no existe.");
        }
    }

    @GetMapping
    public ResponseEntity<List<Paciente>> buscarTodos(){ return ResponseEntity.ok(pacienteService.buscarTodos());}
}
