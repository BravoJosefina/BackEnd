package com.example.clinicaOdontologica.controller;

import com.example.clinicaOdontologica.models.Odontologo;
import com.example.clinicaOdontologica.service.OdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/odontologos")
@CrossOrigin("*")
public class OdontologoController {
    @Autowired
    private OdontologoService odontologoService;

    @PostMapping()
    public ResponseEntity<Odontologo> registrarOdontologo(@RequestBody Odontologo odontologo){
        Odontologo nuevoOdontologo = odontologoService.guardar(odontologo);
        if(nuevoOdontologo != null){
            return ResponseEntity.ok(nuevoOdontologo);
        }else{
            return ResponseEntity.internalServerError().body(null);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Odontologo> buscar(@PathVariable Integer id){
       Odontologo odontologoBuscado = odontologoService.buscar(id);
       if(odontologoBuscado != null){
           return ResponseEntity.ok(odontologoBuscado);
       }else{
           return ResponseEntity.badRequest().body(null);
       }
    }

    @PutMapping()
    public ResponseEntity<Odontologo> actualizar(@RequestBody Odontologo odontologo){
        ResponseEntity<Odontologo> responde=null;
        Odontologo odontologoPorActualizar = odontologoService.buscar(odontologo.getId());
        if(odontologoPorActualizar != null){
            return ResponseEntity.ok(odontologoService.actualizar(odontologo));
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @DeleteMapping(value= "/{id}")
    public ResponseEntity eliminar(@PathVariable Integer id) {
        if (odontologoService.eliminar(id)) {
            return ResponseEntity.ok("Odontologo con id " + id + " fue eliminado");
        } else {
            return ResponseEntity.badRequest().body("Odontologo con id " + id + " no existe.");
        }
    }

    @GetMapping
    public ResponseEntity<List<Odontologo>> buscarTodos(){ return ResponseEntity.ok(odontologoService.buscarTodos());}
}
