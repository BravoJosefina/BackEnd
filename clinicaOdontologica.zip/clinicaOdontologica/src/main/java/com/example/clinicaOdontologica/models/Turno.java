//package com.example.clinicaOdontologica.models;
//
//
//import javax.persistence.*;
//import java.util.Date;
//
//@Entity
//@Table
//public class Turno {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//
//    private Paciente paciente;
//    private Odontologo odontologo;
//    private Date date;
//
//
//
//    public Turno(){
//    }
//
//    public Turno(Paciente paciente, Odontologo odontologo, Date date) {
//        this.paciente = paciente;
//        this.odontologo = odontologo;
//        this.date = date;
//    }
//
//    public Paciente getPaciente() {
//        return paciente;
//    }
//
//    public void setPaciente(Paciente paciente) {
//        this.paciente = paciente;
//    }
//
//    public Odontologo getOdontologo() {
//        return odontologo;
//    }
//
//    public void setOdontologo(Odontologo odontologo) {
//        this.odontologo = odontologo;
//    }
//
//    public Date getDate() {
//        return date;
//    }
//
//    public void setDate(Date date) {
//        this.date = date;
//    }
//
//    @Override
//    public String toString() {
//        return "Turno{" +
//                "paciente=" + paciente +
//                ", odontologo=" + odontologo +
//                ", date=" + date +
//                '}';
//    }
//}
