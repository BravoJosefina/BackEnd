package com.example.clinicaOdontologica.service;

import com.example.clinicaOdontologica.models.Domicilio;
import com.example.clinicaOdontologica.repository.DomicilioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class DomicilioService {
    @Autowired
    private DomicilioRepository repository;

    public Domicilio guardar(Domicilio domicilio){
        if (domicilio.getId() != null){
            return null;
        }
        else{
            return repository.save(domicilio);
        }}
    public Domicilio buscar(Integer id){
        try{
            return repository.getById(id);
        }catch(NoSuchElementException e){
            return null;
        }
    }
    public Domicilio actualizar(Domicilio domicilio){
        return repository.save(domicilio);
    }

    public Boolean eliminar(Integer id){
        if(repository.existsById(id)){
            repository.deleteById(id);
            return true;
        }return false;
    }

    public List<Domicilio> buscarTodos(){return repository.findAll();}
}